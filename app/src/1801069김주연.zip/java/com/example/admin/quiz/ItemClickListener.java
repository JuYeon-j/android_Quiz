package com.example.admin.quiz;

import android.view.View;

public interface ItemClickListener {
    public void onItemClick(View v,int index);
}
